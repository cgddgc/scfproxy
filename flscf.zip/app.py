#!python3
#-*-coding:utf-8-*-


from flask import Flask, request, make_response
import json
import requests, base64

class fconfig:
    DEBUG = True


app = Flask(__name__)
app.config.from_object(fconfig)

@app.route('/<token>', methods = ['POST'])
def proxy(token): 
    if token == 'it00ls':   
        raw_data = json.loads(base64.b64decode(request.json['data']))

        headers = json.loads(base64.b64decode(raw_data['headers']).decode())
        headers['Accept-Encoding'] = 'deflate'
        
        data = base64.b64decode(raw_data['data'])

        res = requests.request(raw_data['method'], raw_data['url'], data = data, headers = headers, allow_redirects = False,verify = False)
        ret = make_response(res.content, res.status_code)
        for k, v in res.headers.items():
            ret.headers[k] = v

        return ret
    else:
        return '', 404


app.run(host = '0.0.0.0', port = 9000)