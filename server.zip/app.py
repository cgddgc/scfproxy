#!python3
#-*-coding:utf-8-*-

from flask import Flask, request, make_response
import json, pickle
import requests, base64

class fconfig:
    DEBUG = True


app = Flask(__name__)
app.config.from_object(fconfig)

@app.before_request
def proxy():    
    ret = make_response('404', 404)
    #print(request.headers)
    if 'User-Agent' in request.headers and request.headers['User-Agent'] == 'scfproxy-client':
        raw_data = json.loads(base64.b64decode(request.json['data']))
        headers = json.loads(base64.b64decode(raw_data['headers']).decode())

        data = base64.b64decode(raw_data['data'])
        try:
            res = requests.request(raw_data['method'], raw_data['url'], data = data, headers = headers, allow_redirects = False,verify = False)
            #print(res.content)
            rawres = base64.b64encode(pickle.dumps(res)).decode('utf-8')
            ret = make_response(rawres, res.status_code)
        except requests.exceptions.ConnectionError:
            ret = make_response('连接失败', 503)


    return ret


app.run(host = '0.0.0.0', port = 9000)